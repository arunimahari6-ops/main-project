from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from gallery.models import DesignProject
from .forms import DesignProjectForm

from bookings.models import BookingRequest

@login_required
def designer_dashboard(request):
    if not request.user.is_designer:
        return redirect('home')
    
    # Handle quick status updates from dashboard
    if request.method == 'POST':
        booking_id = request.POST.get('booking_id')
        new_status = request.POST.get('status')
        if booking_id and new_status:
            booking = get_object_or_404(BookingRequest, id=booking_id, designer=request.user)
            booking.status = new_status
            booking.save()
            return redirect('designer_dashboard')

    projects = DesignProject.objects.filter(designer=request.user)
    pending_bookings = BookingRequest.objects.filter(designer=request.user, status='pending').order_by('-created_at')
    
    context = {
        'projects': projects,
        'pending_bookings': pending_bookings,
    }
    return render(request, 'designers/dashboard.html', context)

@login_required
def upload_design(request):
    if not request.user.is_designer:
        return redirect('home')
    
    if request.method == 'POST':
        form = DesignProjectForm(request.POST, request.FILES)
        if form.is_valid():
            project = form.save(commit=False)
            project.designer = request.user
            project.save()
            return redirect('designer_dashboard')
    else:
        form = DesignProjectForm()
    
    return render(request, 'designers/upload_design.html', {'form': form})

@login_required
def edit_design(request, project_id):
    project = get_object_or_404(DesignProject, id=project_id, designer=request.user)
    if request.method == 'POST':
        form = DesignProjectForm(request.POST, request.FILES, instance=project)
        if form.is_valid():
            form.save()
            return redirect('designer_dashboard')
    else:
        form = DesignProjectForm(instance=project)
    
    return render(request, 'designers/upload_design.html', {'form': form, 'is_edit': True})

@login_required
def delete_design(request, project_id):
    project = get_object_or_404(DesignProject, id=project_id, designer=request.user)
    if request.method == 'POST':
        project.delete()
        return redirect('designer_dashboard')
    return render(request, 'designers/confirm_delete.html', {'project': project})
