from django import forms
from gallery.models import DesignProject

class DesignProjectForm(forms.ModelForm):
    class Meta:
        model = DesignProject
        fields = ['title', 'description', 'image', 'category', 'estimated_cost']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }
