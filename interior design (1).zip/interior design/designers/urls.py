from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.designer_dashboard, name='designer_dashboard'),
    path('upload/', views.upload_design, name='upload_design'),
    path('edit/<int:project_id>/', views.edit_design, name='edit_design'),
    path('delete/<int:project_id>/', views.delete_design, name='delete_design'),
]
