from django.urls import path
from . import views

urlpatterns = [
    path('', views.gallery_home, name='gallery_home'),
    path('design/<int:project_id>/', views.design_detail, name='design_detail'),
    path('favorite/<int:project_id>/', views.toggle_favorite, name='toggle_favorite'),
    path('my-shortlist/', views.my_favorites, name='my_favorites'),
]
