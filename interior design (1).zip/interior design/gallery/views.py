from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from .models import DesignProject, Category, Favorite

def gallery_home(request):
    projects = DesignProject.objects.filter(is_approved=True).order_by('-created_at')
    categories = Category.objects.all()
    
    # Filtering
    query = request.GET.get('q')
    category_id = request.GET.get('category')
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')

    if query:
        projects = projects.filter(Q(title__icontains=query) | Q(description__icontains=query))
    
    if category_id:
        projects = projects.filter(category_id=category_id)
        
    if min_price:
        projects = projects.filter(estimated_cost__gte=min_price)
    
    if max_price:
        projects = projects.filter(estimated_cost__lte=max_price)

    return render(request, 'gallery/gallery_home.html', {
        'projects': projects,
        'categories': categories,
    })

def design_detail(request, project_id):
    project = get_object_or_404(DesignProject, id=project_id)
    is_favorited = False
    if request.user.is_authenticated:
        is_favorited = Favorite.objects.filter(user=request.user, project=project).exists()
        
    return render(request, 'gallery/design_detail.html', {'project': project, 'is_favorited': is_favorited})

@login_required
def toggle_favorite(request, project_id):
    project = get_object_or_404(DesignProject, id=project_id)
    favorite, created = Favorite.objects.get_or_create(user=request.user, project=project)
    if not created:
        favorite.delete()
    return redirect('design_detail', project_id=project.id)

@login_required
def my_favorites(request):
    favorites = Favorite.objects.filter(user=request.user).select_related('project')
    return render(request, 'gallery/my_favorites.html', {'favorites': favorites})
