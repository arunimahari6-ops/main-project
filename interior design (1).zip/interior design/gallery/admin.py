from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(DesignProject)
admin.site.register(Favorite)