from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import BookingRequest
from .forms import BookingRequestForm
from gallery.models import DesignProject

@login_required
def create_booking(request, project_id):
    project = get_object_or_404(DesignProject, id=project_id)
    if request.method == 'POST':
        form = BookingRequestForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.customer = request.user
            booking.designer = project.designer
            booking.project_interest = project
            booking.save()
            return redirect('booking_success')
    else:
        form = BookingRequestForm()
    
    return render(request, 'bookings/create_booking.html', {'form': form, 'project': project})

@login_required
def booking_success(request):
    return render(request, 'bookings/success.html')

@login_required
def designer_bookings(request):
    if not request.user.is_designer:
        return redirect('home')
    
    bookings = BookingRequest.objects.filter(designer=request.user).order_by('-created_at')
    
    # Handle status updates
    if request.method == 'POST':
        booking_id = request.POST.get('booking_id')
        new_status = request.POST.get('status')
        if booking_id and new_status:
            booking = get_object_or_404(BookingRequest, id=booking_id, designer=request.user)
            booking.status = new_status
            booking.save()
            return redirect('designer_bookings')

    return render(request, 'bookings/designer_bookings.html', {'bookings': bookings})

@login_required
def my_bookings(request):
    # Customer view of their bookings
    bookings = BookingRequest.objects.filter(customer=request.user).order_by('-created_at')
    return render(request, 'bookings/my_bookings.html', {'bookings': bookings})
