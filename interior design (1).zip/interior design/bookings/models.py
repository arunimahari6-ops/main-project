from django.db import models
from django.conf import settings
from gallery.models import DesignProject

class BookingRequest(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('completed', 'Completed'),
    )

    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='bookings')
    designer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='received_requests', limit_choices_to={'is_designer': True})
    project_interest = models.ForeignKey(DesignProject, on_delete=models.SET_NULL, null=True, blank=True, help_text="Optional: If they are interested in a specific design")
    message = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Booking from {self.customer.username} to {self.designer.username}"
