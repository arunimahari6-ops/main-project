from django.urls import path
from . import views

urlpatterns = [
    path('request/<int:project_id>/', views.create_booking, name='create_booking'),
    path('success/', views.booking_success, name='booking_success'),
    path('manage/', views.designer_bookings, name='designer_bookings'),
    path('my-requests/', views.my_bookings, name='my_bookings'),
]
