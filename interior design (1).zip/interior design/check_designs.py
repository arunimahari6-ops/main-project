import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "interior_design_project.settings")
django.setup()

from gallery.models import DesignProject

projects = DesignProject.objects.all()
print(f"Total Projects: {projects.count()}")
for p in projects:
    print(f"- {p.title} (Designer: {p.designer.username}) | Approved: {p.is_approved}")
