import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "interior_design_project.settings")
django.setup()

from gallery.models import Category

categories = [
    'Living Room',
    'Bedroom',
    'Kitchen',
    'Bathroom',
    'Office',
    'Outdoor',
    'Dining Room'
]

for name in categories:
    Category.objects.get_or_create(name=name)
    print(f"Category '{name}' ensured.")
