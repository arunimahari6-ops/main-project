from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User

class CustomerSignUpForm(UserCreationForm):
    phone_number = forms.CharField(required=False)
    address = forms.CharField(widget=forms.Textarea, required=False)

    class Meta(UserCreationForm.Meta):
        model = User
        fields = UserCreationForm.Meta.fields + ('email', 'first_name', 'last_name', 'phone_number', 'address')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.is_customer = True
        if commit:
            user.save()
        return user

class DesignerSignUpForm(UserCreationForm):
    phone_number = forms.CharField(required=False)
    address = forms.CharField(widget=forms.Textarea, required=False)
    
    # Designer specific fields
    bio = forms.CharField(widget=forms.Textarea, required=False)
    experience_years = forms.IntegerField(required=True)
    specialization = forms.CharField(required=True)
    website = forms.URLField(required=False)

    class Meta(UserCreationForm.Meta):
        model = User
        fields = UserCreationForm.Meta.fields + ('email', 'first_name', 'last_name', 'phone_number', 'address')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.is_designer = True
        if commit:
            user.save()
            # Create DesignerProfile
            from designers.models import DesignerProfile
            DesignerProfile.objects.create(
                user=user,
                bio=self.cleaned_data.get('bio'),
                experience_years=self.cleaned_data.get('experience_years'),
                specialization=self.cleaned_data.get('specialization'),
                website=self.cleaned_data.get('website')
            )
        return user
