from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.views.generic import CreateView, TemplateView
from django.contrib import messages
from .forms import CustomerSignUpForm, DesignerSignUpForm
from .update_forms import UserUpdateForm, DesignerProfileUpdateForm
from .models import User
from gallery.models import Category

def home(request):
    categories = Category.objects.all()[:5] # Get first 5 categories for the slider
    return render(request, 'home.html', {'styles': categories})

@login_required
def login_redirect(request):
    if request.user.is_superuser:
        return redirect('admin_dashboard')
    elif request.user.is_designer:
        return redirect('designer_dashboard')
    else:
        # Customer or regular user
        return redirect('home')

class SignUpView(TemplateView):
    template_name = 'accounts/signup_selection.html'

class CustomerSignUpView(CreateView):
    model = User
    form_class = CustomerSignUpForm
    template_name = 'accounts/signup_form.html'

    def get_context_data(self, **kwargs):
        kwargs['user_type'] = 'Customer'
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        # Redirect new customers to home
        return redirect('home')

class DesignerSignUpView(CreateView):
    model = User
    form_class = DesignerSignUpForm
    template_name = 'accounts/signup_form.html'

    def get_context_data(self, **kwargs):
        kwargs['user_type'] = 'Designer'
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        # Redirect new designers to their dashboard
        return redirect('designer_dashboard')

@login_required
def admin_dashboard(request):
    if not request.user.is_superuser:
        return redirect('home')
    
    # Import here to avoid circular imports
    from designers.models import DesignerProfile
    from gallery.models import DesignProject
    from bookings.models import BookingRequest

    # Handle Admin Actions
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'approve' or action == 'reject':
            project_id = request.POST.get('project_id')
            if project_id:
                project = DesignProject.objects.get(id=project_id)
                if action == 'approve':
                    project.is_approved = True
                    project.save()
                elif action == 'reject':
                    project.delete()
        
        elif action == 'delete_designer':
            designer_id = request.POST.get('designer_id')
            if designer_id:
                designer = get_object_or_404(User, id=designer_id, is_designer=True)
                designer.delete()
        
        elif action == 'delete_booking':
            booking_id = request.POST.get('booking_id')
            if booking_id:
                booking = get_object_or_404(BookingRequest, id=booking_id)
                booking.delete()
                
        return redirect('admin_dashboard')
    
    context = {
        'total_customers': User.objects.filter(is_customer=True).count(),
        'total_designers': User.objects.filter(is_designer=True).count(),
        'total_projects': DesignProject.objects.count(),
        'total_bookings': BookingRequest.objects.count(),
        'recent_projects': DesignProject.objects.order_by('-created_at')[:5],
        'recent_bookings': BookingRequest.objects.order_by('-created_at')[:5],
        'pending_approvals': DesignProject.objects.filter(is_approved=False).order_by('created_at'),
        'designers': User.objects.filter(is_designer=True).order_by('username'),
    }
    return render(request, 'accounts/admin_dashboard.html', context)

@login_required
def edit_profile(request):
    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, request.FILES, instance=request.user)
        designer_form = None
        if request.user.is_designer:
            designer_form = DesignerProfileUpdateForm(request.POST, instance=request.user.designer_profile)
        
        if user_form.is_valid() and (not designer_form or designer_form.is_valid()):
            user_form.save()
            if designer_form:
                designer_form.save()
            messages.success(request, 'Your profile has been updated!')
            return redirect('edit_profile')
    else:
        user_form = UserUpdateForm(instance=request.user)
        designer_form = None
        if request.user.is_designer:
            designer_form = DesignerProfileUpdateForm(instance=request.user.designer_profile)

    return render(request, 'accounts/edit_profile.html', {
        'user_form': user_form,
        'designer_form': designer_form
    })
