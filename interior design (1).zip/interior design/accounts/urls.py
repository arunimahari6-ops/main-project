from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('signup/', views.SignUpView.as_view(), name='signup'),
    path('signup/customer/', views.CustomerSignUpView.as_view(), name='customer_signup'),
    path('signup/designer/', views.DesignerSignUpView.as_view(), name='designer_signup'),
    path('login/', auth_views.LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('redirect/', views.login_redirect, name='login_redirect'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),
]
