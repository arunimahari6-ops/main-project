from django import forms
from django.contrib.auth import get_user_model
from designers.models import DesignerProfile

User = get_user_model()

class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'phone_number', 'address', 'profile_picture']

class DesignerProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = DesignerProfile
        fields = ['bio', 'experience_years', 'specialization', 'website']
